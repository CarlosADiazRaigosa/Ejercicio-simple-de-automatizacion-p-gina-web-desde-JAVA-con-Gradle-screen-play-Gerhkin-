package co.com.bancolombia.certificacion.utest.questions;

import co.com.bancolombia.certificacion.utest.userinterfaces.RegisterUser;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class MessageValidate implements Question {

    @Override
    public Object answeredBy(Actor actor) {

        return Text.of(RegisterUser.LBL_MESSAGE).viewedBy(actor).asString();
    }

    public static MessageValidate successAcount(){
        return new MessageValidate();
    }
}
