package co.com.bancolombia.certificacion.utest.taks;

import co.com.bancolombia.certificacion.utest.models.Persona;
import co.com.bancolombia.certificacion.utest.userinterfaces.RegisterUser;
import net.bytebuddy.asm.Advice;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.*;
import net.serenitybdd.screenplay.actions.selectactions.SelectByValueFromTarget;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.Select;


import java.util.List;

public class IngresarLaInformacion implements Task {


    private String firstName;
    private String lastName;
    private String email;
    private String birthDay;
    private String birthMonth;
    private String birthYear;
    private String city;
    private String zip;
    private String country;
    private String pass;
    private String confirmPass;

    public IngresarLaInformacion() {

    }


    public IngresarLaInformacion(List<Persona> datos) {
        this.firstName = datos.get(0).getFirstName();
        this.lastName = datos.get(0).getLastName();
        this.email = datos.get(0).getEmail();
        this.birthDay = datos.get(0).getBirthDay();
        this.birthMonth = datos.get(0).getBirthMonth();
        this.birthYear = datos.get(0).getBirthYear();
        this.city = datos.get(0).getCity();
        this.zip = datos.get(0).getZip();
        this.country = datos.get(0).getCountry();
        this.pass = datos.get(0).getPass();
        this.confirmPass = datos.get(0).getConfirmPass();
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Enter.theValue(firstName).into(RegisterUser.LBL_USERNAME),
                Enter.theValue(lastName).into(RegisterUser.LBL_LASTNAME),
                Enter.theValue(email).into(RegisterUser.LBL_EMAIL),
                SelectFromOptions.byVisibleText(birthDay).from(RegisterUser.LBL_BIRTHDAY),
                SelectFromOptions.byVisibleText(birthMonth).from(RegisterUser.LBL_BIRTHMONTH),
                SelectFromOptions.byVisibleText(birthYear).from(RegisterUser.LBL_BIRTHYEAR),
                Click.on(RegisterUser.LBL_NEXTBTN),
                Enter.theValue(city).into(RegisterUser.LBL_CITY),
                Hit.the(Keys.ARROW_DOWN).keyIn(RegisterUser.LBL_CITY),
                WaitUntil.the(RegisterUser.LBL_ZIP, WebElementStateMatchers.isEnabled()),
                Hit.the(Keys.ARROW_DOWN).keyIn(RegisterUser.LBL_ZIP),
                Enter.theValue(zip).into(RegisterUser.LBL_ZIP),
                WaitUntil.the(RegisterUser.LBLDVCBTN, WebElementStateMatchers.isEnabled()),
                Click.on(RegisterUser.LBLDVCBTN),
                Click.on(RegisterUser.LBLSTPBTN),
                //Enter.theValue(country).into(RegisterUser.LBL_COUNTRY),
                Enter.theValue(pass).into(RegisterUser.LBL_PASSWORD),
                Enter.theValue(confirmPass).into(RegisterUser.LBL_CONFIRMPASSWORD),
                Click.on(RegisterUser.LBL_ACCEPTTERMS),
                Click.on(RegisterUser.LBL_ACCEPTPOLICIES),
                Click.on(RegisterUser.LBL_COMPLETEBTN),
                WaitUntil.the(RegisterUser.LBL_MESSAGE, WebElementStateMatchers.isEnabled()).
                        forNoMoreThan(120).seconds());
        }
        public static IngresarLaInformacion delUsuario (List<Persona> personas) {
            return Tasks.instrumented(IngresarLaInformacion.class, personas);

        }

}
