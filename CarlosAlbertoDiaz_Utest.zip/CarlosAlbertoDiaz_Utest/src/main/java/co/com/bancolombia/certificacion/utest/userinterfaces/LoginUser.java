package co.com.bancolombia.certificacion.utest.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class LoginUser {
    public static final Target LBL_EMAIL = Target.the("Field Email").located(By.name("username"));
    public static final Target LBL_PASSWORD = Target.the("Field Password").located(By.xpath("//input[@id='password']"));
    public static final Target LBL_SIGNIN = Target.the("Register button").located(By.xpath("//button[@id='kc-login']"));
}
