package co.com.bancolombia.certificacion.utest.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class RegisterUser {
    public static final Target LBL_USERNAME = Target.the("Field Name").located(By.name("firstName"));
    public static final Target LBL_LASTNAME = Target.the("Field Lastname").located(By.name("lastName"));
    public static final Target LBL_EMAIL = Target.the("Field Email").located(By.name("email"));
    public static final Target LBL_BIRTHMONTH = Target.the("Field Birthmonth").located(By.name("birthMonth"));
    public static final Target LBL_BIRTHDAY = Target.the("Field Birthday").located(By.name("birthDay"));
    public static final Target LBL_BIRTHYEAR = Target.the("Field Birthyear").located(By.name("birthYear"));
    public static final Target LBL_NEXTBTN = Target.the("Next Location Button").located(By.xpath("//body/ui-view[1]/main[1]/section[1]/div[1]/div[2]/div[1]/div[2]/div[1]/form[1]/div[2]/a[1]"));
    public static final Target LBL_CITY = Target.the("Field City").located(By.id("city"));
    public static final Target LBL_ZIP = Target.the("Field Zip").located(By.name("zip"));
    public static final Target LBLDVCBTN = Target.the(" Next Devices Button").located(By.xpath("//body/ui-view[1]/main[1]/section[1]/div[1]/div[2]/div[1]/div[2]/div[1]/form[1]/div[2]/div[1]/a[1]"));
    public static final Target LBLSTPBTN = Target.the("Next Setps Button").located(By.xpath("//body/ui-view[1]/main[1]/section[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[2]/div[1]/a[1]"));
    public static final Target LBL_COUNTRY = Target.the("Field Country").located(By.xpath(""));
    public static final Target LBL_PASSWORD = Target.the("Field Password").located(By.xpath("//body/ui-view[1]/main[1]/section[1]/div[1]/div[2]/div[1]/div[2]/div[1]/form[1]/div[3]/div[1]/input[1]"));
    public static final Target LBL_CONFIRMPASSWORD = Target.the("Field ConfirmPassword").located(By.xpath("//body/ui-view[1]/main[1]/section[1]/div[1]/div[2]/div[1]/div[2]/div[1]/form[1]/div[3]/div[2]/input[1]"));
    public static final Target LBL_ACCEPTTERMS = Target.the("Field Accept Terms").located(By.xpath("//body/ui-view[1]/main[1]/section[1]/div[1]/div[2]/div[1]/div[2]/div[1]/form[1]/div[5]/label[1]/span[1]"));
    public static final Target LBL_ACCEPTPOLICIES = Target.the("Field accept Policies").located(By.xpath("//body/ui-view[1]/main[1]/section[1]/div[1]/div[2]/div[1]/div[2]/div[1]/form[1]/div[6]/label[1]/span[1]"));
    public static final Target LBL_COMPLETEBTN = Target.the("Button Complete").located(By.xpath("//span[contains(text(),'Complete Setup')]"));
    public static final Target LBL_MESSAGE = Target.the("Message").located(By.xpath("//strong[contains(text(),'As a new tester, we recommend that you follow thes')]"));

}
