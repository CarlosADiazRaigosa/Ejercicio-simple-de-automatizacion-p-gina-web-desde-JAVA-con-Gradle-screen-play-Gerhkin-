package co.com.bancolombia.certificacion.utest.taks;

import co.com.bancolombia.certificacion.utest.models.Persona;
import co.com.bancolombia.certificacion.utest.userinterfaces.LoginUser;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import java.util.List;

public class LogninUser implements Task {

    private String lognInEmail;
    private String lognInPassword;

    public void LogninUser() {

    }
    public LogninUser(List<Persona> datos) {
        this.lognInEmail= datos.get(0).getEmail();
        this.lognInPassword= datos.get(0).getPass();
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(Enter.theValue(lognInEmail).into(LoginUser.LBL_EMAIL),
                        Enter.theValue(lognInPassword).into(LoginUser.LBL_PASSWORD),
                Click.on(LoginUser.LBL_SIGNIN));
    }

    public static LogninUser delLoginUsuario(List<Persona> Personas) {
        return Tasks.instrumented(LogninUser.class, Personas);
    }
}
