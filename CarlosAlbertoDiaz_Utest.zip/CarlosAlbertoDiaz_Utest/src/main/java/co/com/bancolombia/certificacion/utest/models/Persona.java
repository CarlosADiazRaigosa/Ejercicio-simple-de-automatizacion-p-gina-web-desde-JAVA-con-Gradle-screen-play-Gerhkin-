package co.com.bancolombia.certificacion.utest.models;

import lombok.Data;

@Data
public class Persona {
    private String firstName;
    private String lastName;
    private String email;
    private String birthDay;
    private String birthMonth;
    private String birthYear;
    private String city;
    private String zip;
    private String country;
    private String pass;
    private String confirmPass;
}
