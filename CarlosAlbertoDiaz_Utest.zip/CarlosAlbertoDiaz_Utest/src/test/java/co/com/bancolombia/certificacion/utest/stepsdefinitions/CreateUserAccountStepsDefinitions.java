package co.com.bancolombia.certificacion.utest.stepsdefinitions;

import co.com.bancolombia.certificacion.utest.models.Persona;
import co.com.bancolombia.certificacion.utest.questions.MessageValidate;
import co.com.bancolombia.certificacion.utest.taks.IngresarLaInformacion;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.Cast;
import net.serenitybdd.screenplay.actors.OnStage;
import net.thucydides.core.annotations.Managed;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;

public class CreateUserAccountStepsDefinitions {
    By search = By.name("search");
    @Before
    public void configuracion(){
        OnStage.setTheStage(Cast.whereEveryoneCan(BrowseTheWeb.with(chrome)));
        OnStage.theActorCalled("actor");
    }

    @Managed
    WebDriver chrome;

    @Given("^that user already on the page (.*)$")
    public void thatUserAlreadyOnThePage(String arg1) {

        OnStage.theActorInTheSpotlight().wasAbleTo(Open.url(arg1));
    }

    @Given("^press the join today button (.*)$")
    public void pressTheJoinTodayButton(String arg1) {

        chrome.findElement(By.className(arg1)).click();
    }

    @When("^the user enters their information in each of the forms$")
    public void theUserEntersTheirInformationInEachOfTheForms(List<Persona> personas) {
        OnStage.theActorInTheSpotlight().attemptsTo(IngresarLaInformacion.delUsuario(personas));
    }

    @Then("^will be see next (.*)$")
    public void willBeSeeNext(String msj) {
       OnStage.theActorInTheSpotlight().should(GivenWhenThen.seeThat(MessageValidate.successAcount(), Matchers.equalTo(msj)));
    }


}
