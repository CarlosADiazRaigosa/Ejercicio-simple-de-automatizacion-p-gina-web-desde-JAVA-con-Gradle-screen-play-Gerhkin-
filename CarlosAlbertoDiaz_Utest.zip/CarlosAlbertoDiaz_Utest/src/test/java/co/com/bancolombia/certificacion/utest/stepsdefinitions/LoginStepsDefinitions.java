package co.com.bancolombia.certificacion.utest.stepsdefinitions;

import co.com.bancolombia.certificacion.utest.models.Persona;
import co.com.bancolombia.certificacion.utest.taks.IngresarLaInformacion;
import co.com.bancolombia.certificacion.utest.taks.LogninUser;
import co.com.bancolombia.certificacion.utest.userinterfaces.LoginUser;
import co.com.bancolombia.certificacion.utest.userinterfaces.RegisterUser;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.Cast;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.List;

public class LoginStepsDefinitions {

    @Before
    public void configuracion(){
        OnStage.setTheStage(Cast.whereEveryoneCan(BrowseTheWeb.with(chrome)));
        OnStage.theActorCalled("actor");
    }

    @Managed
    WebDriver chrome;

    @Given("^press the join login button (.*)$")
    public void press_the_join_login_button (String arg1) {
        //WaitUntil.the(RegisterUser.LBL_ZIP, WebElementStateMatchers.isEnabled()),
        //WaitUntil.the(LoginUser.LBL_SIGNIN, WebElementStateMatchers.isEnabled());
        chrome.findElement(By.xpath(arg1)).click();
    }

    @When("^the user enters their information Lognin$")
    public void theUserEntersTheirInformationLognin(List<Persona> personas) {
        OnStage.theActorInTheSpotlight().attemptsTo(LogninUser.delLoginUsuario(personas));
    }

}
